package proyecto_hospital;
public class Proyecto_Hospital {
    public static void main(String[] args) {
        Interface_Menu a = new Interface_Menu ();
        a.setTitle("Menu");
        a.setVisible(true);
    }
    
}
