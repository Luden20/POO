package proyecto_mascotas;
public class Proyecto_mascotas {

    public static void main(String[] args) {
        MENU a = new MENU();
        a.setTitle("DATOS");
            a.setVisible(true);
    }
    
}
